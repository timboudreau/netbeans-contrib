/*
* Copyright 2005 Sun Microsystems, Inc. All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* - Redistributions of source code must retain the above copyright
*   notice, this list of conditions and the following disclaimer.
*
* - Redistribution in binary form must reproduce the above copyright
*   notice, this list of conditions and the following disclaimer in
*   the documentation and/or other materials provided with the
*   distribution.
*
* Neither the name of Sun Microsystems, Inc. or the names of
* contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* This software is provided "AS IS," without a warranty of any
* kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
* WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
* EXCLUDED. SUN AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
* DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SUN
* OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR
* FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR
* PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
* LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
* EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
* You acknowledge that Software is not designed, licensed or intended
* for use in the design, construction, operation or maintenance of
* any nuclear facility.
*/

package com.sun.j2ee.blueprints.processmanager.ejb;

import java.util.Collection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.ejb.DuplicateKeyException;

import com.sun.j2ee.blueprints.processmanager.manager.ejb.ManagerLocal;
import com.sun.j2ee.blueprints.processmanager.manager.ejb.ManagerLocalHome;

import com.sun.j2ee.blueprints.servicelocator.*;
import com.sun.j2ee.blueprints.servicelocator.ejb.*;

public class ProcessManagerBean  implements SessionBean {
    
    public static final String MANAGER_HOME_ENV_NAME =
        "java:comp/env/ejb/local/processmanager/Manager";
    
    private ManagerLocalHome mlh;
   
    /**
     * Business method used for when new purchase orders are recieved 
     * and want to start the workflow process to fullfil the order
     */
    public void createManager(String orderId, String status, 
            String actyOrderStatus, 
            String airlineOrderStatus, 
            String lodgOrderStatus) 
                                       throws CreateException {       
  ManagerLocal manager = mlh.create(orderId, status, actyOrderStatus, 
            airlineOrderStatus, lodgOrderStatus,
            false);            
    }

    /**
     * Business methods used to keep track of an order in the workflow process
     */   

    public void updateStatus(String orderId, String status) 
  throws FinderException {
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  manager.setStatus(status);
    }

    public void updateOrderErrorStatus(String orderId, boolean error) 
  throws FinderException {
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  manager.setOrderError(error);
    }

    public void updateActivityOrderStatus(String orderId, String status) 
  throws FinderException {                                   
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  manager.setActivityOrderStatus(status);
    }

    public void updateAirlineOrderStatus(String orderId, String status) 
  throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  manager.setAirlineOrderStatus(status);  
    }
    
    public void updateLodgingOrderStatus(String orderId, String status) 
  throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  manager.setLodgingOrderStatus(status);   
    }

    public void updateStatusToCompleted(String orderId) throws FinderException{
      //change the order status to completed if all the three suborders
      //are completed
      
  if ( (getActivityOrderStatus(orderId).equalsIgnoreCase(OrderStatusNames.COMPLETED)) &&
       (getAirlineOrderStatus(orderId).equalsIgnoreCase(OrderStatusNames.COMPLETED)) &&
       (getLodgingOrderStatus(orderId).equalsIgnoreCase(OrderStatusNames.COMPLETED))) {   
         ManagerLocal manager = mlh.findByPrimaryKey(orderId);
         manager.setStatus("COMPLETED");
        }
    }


    /**
     * Business methods used to keep track of an order in the workflow process
     */
    public String getOrderStatus(String orderId) throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  return manager.getStatus();
    }

    private String getActivityOrderStatus(String orderId) 
  throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  return manager.getActivityOrderStatus();
    }

    private String getAirlineOrderStatus(String orderId) 
  throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  return manager.getAirlineOrderStatus();
    }

    private String getLodgingOrderStatus(String orderId) 
  throws FinderException {                              
  ManagerLocal manager = mlh.findByPrimaryKey(orderId);
  return manager.getLodgingOrderStatus();
    }



    /**
     * Business method to get all orders of given status for the admin
     */
    public Collection getOrdersByStatus (String status) throws FinderException {
        return mlh.findOrdersByStatus(status);
    }

    public void ejbCreate() throws CreateException {
  try {
      ServiceLocator sl = new ServiceLocator();
      mlh = (ManagerLocalHome) sl.getLocalHome(MANAGER_HOME_ENV_NAME);
  } catch (ServiceLocatorException se) {
      throw new EJBException("Got service locator exception! " + 
           se.getMessage());
  }
    }
    
    // Misc Method
    //=============
    //activate is empty for stateless session EJBs
    public void ejbActivate() { }

    //passivate is empty for stateless session EJBs
    public void ejbPassivate() { }
 
    public void setSessionContext(SessionContext c) { }
    public void ejbRemove() { }

}
