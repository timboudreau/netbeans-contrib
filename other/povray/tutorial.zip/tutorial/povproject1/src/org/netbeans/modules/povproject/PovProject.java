/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
/*
 * PovProject.java
 *
 * Created on February 16, 2005, 3:43 PM
 */

package org.netbeans.modules.povproject;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.Properties;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import org.netbeans.api.povproject.MainFileProvider;
import org.netbeans.api.project.Project;
import org.netbeans.api.project.ProjectInformation;
import org.netbeans.spi.project.ActionProvider;
import org.netbeans.spi.project.ProjectState;
import org.netbeans.spi.project.ui.LogicalViewProvider;
import org.openide.ErrorManager;
import org.openide.filesystems.FileObject;
import org.openide.util.Lookup;
import org.openide.util.Utilities;
import org.openide.util.lookup.Lookups;


/**
 * A simple povray project.
 *
 * @author Timothy Boudreau
 */
public final class PovProject implements Project {
    private final FileObject projectDir;
    LogicalViewProvider logicalView = new PovrayLogicalView(this);

    //Stuff that lives in the lookup for outside code to use
    private final ProjectState state;
    private final MainFileProviderImpl mainFile = new MainFileProviderImpl();
    
    /** Properties key for the main file, the one which will render on build project */
    public static final String KEY_MAINFILE = "main.file";
    
    public PovProject(FileObject projectDir, ProjectState state) {
        this.projectDir = projectDir;
        this.state = state;
    }

    public FileObject getProjectDirectory() {
        return projectDir;
    }
    
    public Lookup getLookup() {
        return Lookups.fixed(new Object[] {
            this,  //project docs require a project be in its lookup
            state, //allow outside code to mark the project as needing saving
            new ActionProviderImpl(), //Provides standard actions like Build
            loadProperties(), //The project properties
            new Info(), //Project information implementation
            logicalView, //Logical view of project implementation
                    
            mainFile,
        }); 
    }
    
    /**
     * Fetches the scenes folder, creating it if necessary. 
     */
    FileObject getScenesFolder(boolean create) {
        FileObject result = 
            projectDir.getFileObject(PovProjectFactory.SCENES_DIR);
        
        if (result == null && create) {
            try {
                result = projectDir.createFolder (PovProjectFactory.SCENES_DIR);
            } catch (IOException ioe) {
                ErrorManager.getDefault().notify(ioe);
            }
        }
        return result;
    }

    /**
     * Finds and loads $PROJECT_ROOT/pvproject/project.properties, where we
     * store configuration info. 
     */
    private Properties loadProperties() {
        FileObject fob = projectDir.getFileObject(PovProjectFactory.SETTINGS_DIR + "/" + PovProjectFactory.PROJECT_PROPFILE);
        Properties result = new Properties();
        if (fob != null) {
            try {
                result.load(fob.getInputStream());
            } catch (Exception e) {
                ErrorManager.getDefault().notify(e);
            }
        }
        return result;
    }
    
    /**
     * Implementation of our own API, MainFileProvider.  Nodes will use this
     * service to allow a menu item to mark which file should get rendered when
     * you render a project.
     */
    private final class MainFileProviderImpl implements MainFileProvider {
        private FileObject mainFile = null;
        boolean checked = false;
        public FileObject getMainFile() {
            if (mainFile == null && !checked) {
                checked = true;
                Properties props = (Properties) getLookup().lookup(Properties.class);
                String path = props.getProperty(KEY_MAINFILE);
                if (path != null) {
                    mainFile = projectDir.getFileObject(path);
                }
            }
            if (mainFile != null && !mainFile.isValid()) {
                return null;
            }
            return mainFile;
        }

        public void setMainFile(FileObject file) {
            assert file != null && file.getPath().startsWith(
                    getProjectDirectory().getPath()) : 
                    "Main file " + file.getPath() + "not under project " + 
                    projectDir.getPath();
            
            boolean changed = (mainFile == null && file != null) || 
                    (mainFile != null && !mainFile.equals(file));
            
            if  (changed) {
                mainFile = file;
                state.markModified();
            }
        }
    }    
    
    /** Implementation of project system's ProjectInformation class */
    private final class Info implements ProjectInformation {
        public Icon getIcon() {
            return new ImageIcon (Utilities.loadImage("org/netbeans/modules/povproject/resources/povicon.gif"));
        }
        
        public String getName() {
            return getProjectDirectory().getName();
        }
        
        public String getDisplayName() {
            return getName();
        }
        
        public void addPropertyChangeListener (PropertyChangeListener pcl) {
            //do nothing, won't change
        }
        
        public void removePropertyChangeListener (PropertyChangeListener pcl) {
            //do nothing, won't change
        }
        
        public Project getProject() {
            return PovProject.this;
        }
    }
    
    /**
     * Action provider implementation that executes common project actions like
     * Build.
     */
    private final class ActionProviderImpl implements ActionProvider {
        public String[] getSupportedActions() {
            return new String[] {
                COMMAND_BUILD, COMMAND_CLEAN, COMMAND_REBUILD,
            };
        }

        public void invokeAction(String command, Lookup context) throws IllegalArgumentException {
            System.err.println("InvokeAction: " + command);
        } 

        public boolean isActionEnabled(String command, Lookup context) throws IllegalArgumentException {
            return true;
        }
    }
}
