TUTORIALS

The modules here are all versions of the same module, as it evolves from a basic project
type and support for .pov files to a full-blown support module.

POVRAY0
Minimal support for recognizing .pov and .inc files.  Provides an DataLoader, a 
DataObject implementation, and a DataNode implementation that provides a few standard
actions and an icon.


POVPROJECT0
Provides a minimal implementation of a non-Ant-based project type.   A simple ProjectFactory that
will look for dirs with a subdir called pvproject/.  Implements a simple Project which ProjectFactory
can create.  Provides a logical view that demonstrates using FilterNodes (the root is the "scenes/"
subdir of the project.  Provides one povray file template.


POVPROJECT1
Introduces a single interface as API for PovProject - MainFileProvider, and adds the logic to store
the name of the main file in the project.properties file.

POVRAY1
Introduces loose coupling between modules:  Adds an action on PovRayDataNode which will look up the
MainFileProvider on the file's project and use it to set the main file for the project 
(PovrayDataNode.SetMainFileAction).  Demonstrates use of Node.getHtmlDisplayName() to boldface 
the main file's display name.  Demostrates using cookies on nodes as a way to tell the former
main project node it is no longer the main project node.


POVPROJECT2
Introduces two more API interfaces into the project type:  RendererService and ViewService.  Note use of Properties objects to handle settings to pass to the povray exe - we'll touch on it later.  Implements 
the build action in the ActionProvider.  Adds an additional template for an empty .inc file

POVRAY2
Adds a ViewAction to the list of actions for PovRayDataNodes, which will open a corresponding image for a
file, rendering it if necessary.


POVRAY3
Same as POVRAY2 (but must be used with POVPROJECT3)

POVPROJECT3
Implements PriviligedTemplates, to add special templates to all PovProject's folder New menus.
Installs standard rendering settings as a set of properties file in the system filesystem.
RendererServiceImpl switches to get renderer properties from the System Filesystem, which 
Adds a Render submenu to all project nodes which allows them to show a submenu of different
sizes to render at.  Adds output window support.


POVRAY4
Same as POVRAY2 and 3

POVPROJECT4
Adds a pov file creation wizard




