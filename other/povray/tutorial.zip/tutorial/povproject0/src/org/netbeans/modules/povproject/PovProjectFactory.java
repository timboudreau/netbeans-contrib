/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
/*
 * PovProjectFactory.java
 *
 * Created on February 16, 2005, 5:38 PM
 */

package org.netbeans.modules.povproject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.netbeans.api.project.Project;
import org.netbeans.spi.project.ProjectFactory;
import org.netbeans.spi.project.ProjectState;
import org.openide.ErrorManager;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;


/**
 * Factory registered into the default Lookup via META-INF/services file entry
 * Responsible for recognizing and loading povray projects.  A povray project
 * is identified as being a directory with a subdirectory "povproject".
 *
 * @see org.openide.util.Lookup
 * @author Timothy Boudreau
 */
public class PovProjectFactory implements ProjectFactory {
    public static final String SETTINGS_DIR = "pvproject";
    public static final String PROJECT_PROPFILE = "project.properties";
    public static final String SCENES_DIR = "scenes";
    
    private Map projectCache = new HashMap();
    
    /** Creates a new instance of PovProjectFactory */
    public PovProjectFactory() {
    }

    public boolean isProject(FileObject projectDirectory) {
        return projectDirectory.getFileObject(SETTINGS_DIR) != null;
    }
    
    /**
     * Scans from any directory down toward the root of the file system,
     * looking for some parent dir with a subdir "povproject" 
     */
    private Project projectFor (FileObject dir, ProjectState state) {
        synchronized (projectCache) {
            Reference ref = (Reference) projectCache.get(dir.getPath());
            Project result = null;
            if (ref != null) {
                result = (Project) ref.get();
            }
            if (result == null) {
                result = new PovProject (dir, state);
                ref = new WeakReference (result);
                projectCache.put (dir.getPath(), ref);
            }
            return result;
        }
    }

    public Project loadProject(FileObject dir, ProjectState state) throws IOException {
        while (dir != null) {
            if (isProject(dir)) {
                return projectFor(dir, state);
            } else {
                dir = dir.getParent();
            }
        }
        return null;
    }

    public void saveProject(final Project project) throws IOException, ClassCastException {
        FileObject projectRoot = project.getProjectDirectory();
        if (projectRoot.getFileObject(SETTINGS_DIR) == null) {
            //If a subproject or something, user *could* manage to delete it.
            //Log a message, but don't show it to the user
            ErrorManager.getDefault().notify (ErrorManager.INFORMATIONAL,
                    new IOException ("Project dir " + projectRoot.getPath() + " deleted," +
                    " cannot save project"));
            return;
        }
        
        FileObject scenesDir = ((PovProject) project).getScenesFolder(true);
        
        FileObject propertiesFile = projectRoot.getFileObject(SETTINGS_DIR + "/" + PROJECT_PROPFILE);
        if (propertiesFile == null) {
            //Recreate the properties file if needed
            propertiesFile = projectRoot.createData(SETTINGS_DIR + "/" + PROJECT_PROPFILE);
        }

        Properties properties = (Properties) project.getLookup().lookup (Properties.class);
        
        File f = FileUtil.toFile(propertiesFile);
        properties.store(new FileOutputStream(f), "NetBeans Povray Project Properties");
    }
}
