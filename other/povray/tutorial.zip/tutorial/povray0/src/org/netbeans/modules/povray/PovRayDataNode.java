/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
/*
 * PovRayDataNode.java
 *
 * Created on February 16, 2005, 4:36 PM
 */

package org.netbeans.modules.povray;

import java.awt.Image;
import javax.swing.Action;
import org.openide.actions.CopyAction;
import org.openide.actions.CutAction;
import org.openide.actions.DeleteAction;
import org.openide.actions.EditAction;
import org.openide.actions.RenameAction;
import org.openide.loaders.DataNode;
import org.openide.nodes.Children;
import org.openide.util.Utilities;
import org.openide.util.actions.SystemAction;



/**
 * A DataNode for POV-Ray objects
 *
 * @author Timothy Boudreau
 */
public class PovRayDataNode extends DataNode {
    
    /** Creates a new instance of PovRayDataNode */
    public PovRayDataNode(PovRayDataObject obj) {
        super (obj, Children.LEAF);
    }
    
    public Image getIcon(int type) {
        return Utilities.loadImage(
            "org/netbeans/modules/povray/resources/povicon.gif"); //NOI18N
    }
    
    public Action[] getActions(boolean context) {
        Action[] result = new Action[] {
            SystemAction.get (EditAction.class),
            SystemAction.get (CutAction.class),
            SystemAction.get (CopyAction.class),
            SystemAction.get (RenameAction.class),
            SystemAction.get (DeleteAction.class),
        };
        return result;
    }
    
    public Action getPreferredAction() {
        return SystemAction.get (EditAction.class);
    } 
}
