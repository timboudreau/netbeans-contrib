/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
/*
 * RendererServiceImpl.java
 *
 * Created on February 17, 2005, 4:32 PM
 */

package org.netbeans.modules.povproject;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.prefs.Preferences;
import javax.swing.JFileChooser;
import org.netbeans.api.povproject.MainFileProvider;
import org.netbeans.api.povproject.RendererService;
import org.openide.DialogDisplayer;
import org.openide.ErrorManager;
import org.openide.NotifyDescriptor;
import org.openide.awt.StatusDisplayer;
import org.openide.cookies.OpenCookie;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.DataObject;
import org.openide.util.NbBundle;
import org.openide.util.Utilities;
import org.openide.windows.IOProvider;
import org.openide.windows.WindowManager;

/**
 * A service which launches command-line POV-Ray, available in the 
 * project's lookup as an instance of RendererService.
 *
 * XXX - the output handling is really messy and full of busywaits;  there
 * must be a better way to find out if a process is done than checking its
 * exit code and looking for that not to throw an exception.
 *
 * @author Timothy Boudreau
 */
final class RendererServiceImpl implements RendererService {
    private PovProject project;
    private static File povray = null;
    private static File include = null;
    
    /** Preferences key for the povray executable */
    private static final String KEY_POVRAY_EXEC = "povray";
    /** Preferences key for the povray standard includes dir */
    private static final String KEY_POVRAY_INCLUDES = "include";
    
    
    /** Creates a new instance of RendererServiceImpl */
    public RendererServiceImpl(PovProject project) {
        this.project = project;
    }

    //TODO - Cancel render action provided to IOProvider.getIO() for the output toolbar
    

    public File render(File scene) {
        return render (scene, null);
    }

    public File render() {
        MainFileProvider provider = (MainFileProvider) project.getLookup().lookup (MainFileProvider.class);
        FileObject main = provider.getMainFile();
        if (main == null) {
            //XXX ask the user for a main file
            return null;
        }
        return render (FileUtil.toFile(main));
    }

    /**
     * Do the actual rendering.
     * @param scene - the file to render
     * @param renderSettings - properties such as width, height, etc. to send
     *   to the renderer
     */
    public File render(final File scene, Properties renderSettings) {
        assert scene.exists() : "Scene file " + scene + " doesn't exist";
        if (renderSettings == null) {
            renderSettings = getRendererSettings(getPreferredConfigurationName());
        }
        
        //Find the exe, prompting the user if need be
        File povray = getPovray();
        if (povray == null) {
            return null; //the user cancelled
        }
        
        //Make sure we know the standard include dir or many things won't
        //render
        File includes = getStandardIncludeDir(povray);
        if (includes == null) {
            return null; //the user cancelled
        }
        
        //Build the command line to pass to the process, assembling the
        //arguments from the passed data
        StringBuffer cmdline = new StringBuffer (quote(povray.getPath()) + " ");
        for (Iterator i=renderSettings.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            String val = renderSettings.getProperty(key);
            cmdline.append ('+');
            cmdline.append (key);
            cmdline.append (val);
            cmdline.append (' ');
        }
        //Add the input file
        cmdline.append ("+I");
        cmdline.append (quote(scene.getPath()));
        cmdline.append (' ');
        
        //Add the output file
        cmdline.append ("+O");
        FileObject imagesDir = project.getProjectDirectory().getFileObject(PovProject.IMAGES_DIR);
        if (imagesDir == null) {
            try {
                imagesDir = project.getProjectDirectory().createFolder(PovProject.IMAGES_DIR);
            } catch (IOException ioe) {
                ErrorManager.getDefault().notify (ioe);
                return null;
            }
        }
        
        //Strip the .pov extension from the scene name to get the raw file name
        String sceneName = scene.getName();
        
        int endIndex;
        if ((endIndex = sceneName.lastIndexOf('.')) != -1) {
            sceneName = sceneName.substring(0, endIndex);
        }
        
        //Create an image file name (use PNG because NetBeans' image module
        //understands that
        final String imagesFile = quote (FileUtil.toFile(imagesDir).getPath() + File.separator + sceneName + ".png");
        cmdline.append (imagesFile);
        cmdline.append (' ');
        
        //Append the library path (the standard includes dir)
        cmdline.append ("+L");
        cmdline.append (quote(includes.getPath()));
        
        try {
            //Preemptively delete the existing image - otherwise a sill dialog 
            //asking to reload the image can appear if it's already open
            if (new File (imagesFile).exists()) {
                //Use FileObject, not File, so NetBeans immediately notices
                //it's been deleted
                FileUtil.toFileObject(new File(imagesFile)).delete();
            }
            
            //Create a new thread so we don't block the UI with our 
            //external process
            Thread thd = new Thread (new PovRunner (scene, imagesFile, cmdline.toString()), 
                    "Povray Runner - " + cmdline + " started " + new Date());
            
            //Run povray
            thd.start();
            
        } catch (Exception ioe) {
            ErrorManager.getDefault().notify(ioe);
            return null;
        }
        //Return File, not FileObject, since you can't have a FileObject for
        //a file that doesn't exist.  Eventually we could do something really
        //slick like an incremental targa reader (TGA format is dead simple)
        return new File(imagesFile);
    }

    /**
     * Runnable which launches the povray process.
     */
    private final class PovRunner implements Runnable {
        private final File sceneFile;
        private final String cmdline;
        private final String imagesFile;
        private Process process = null;

        PovRunner (File sceneFile, String imagesFile, String cmdline) {
            this.sceneFile = sceneFile;
            this.cmdline = cmdline;
            this.imagesFile = imagesFile;
        }
        
        public void run() {
            try {
                synchronized (this) { //protect access to the "process" ivar
                    //Execute the process
                    process = Runtime.getRuntime().exec (cmdline);
                }
            } catch (IOException e) {
                ErrorManager.getDefault().notify (e);
                return;
            }

            //A truly vile way to see if the process is done - 
            //exitValue() will throw an exception if it isn't
            IllegalThreadStateException e = null;
            do {
                try {
                    if (process.exitValue() != 0) {
                        StatusDisplayer.getDefault().setStatusText(
                            NbBundle.getMessage (RendererServiceImpl.class, 
                                "MSG_RenderFailed", new Integer(process.exitValue())));
                    }

                    //If we got here, the process finished
                    e = null;
                    done();
                } catch (IllegalThreadStateException e1) {
                    //If the process *is* still running, exitValue()
                    //threw an exception.  Sleep and check again.
                    e = e1;
                    try {
                        Thread.currentThread().sleep (500);
                    } catch (InterruptedException ex) {
                        return;
                    }
                }
            } while (e != null);
            done();
        }
        
        public void done() {
            try {
                if (process != null) {
                    process.destroy();
                    process = null;
                }

                //Get the images directory
                File imagesDir = new File (imagesFile).getParentFile();
                
                //Force it to refresh - otherwise there may not yet be a
                //FileObject corresponding to the brand new file
                FileObject par = FileUtil.toFileObject(imagesDir);
                if (par == null) {
                    //parse error or something - nothing was rendered
                    return;
                }
                par.refresh();
                
                FileObject fob = FileUtil.toFileObject (new File(imagesFile));
                if (fob == null) {
                    return; //Error - nothing was rendered
                }
                fob.getParent().refresh();

                //Find the DataObject for the file (actually supplied by the
                // Image module)
                DataObject ob = DataObject.find (fob);
                
                //Get its open cookie, if any
                OpenCookie ck = (OpenCookie) ob.getCookie(OpenCookie.class);
                if (ck != null) {
                    //Open the image
                    ck.open();
                }
            } catch (Exception donfe) {
                ErrorManager.getDefault().notify (donfe);
            }
        }
        
        public int hashCode() {
            return sceneFile.hashCode() ^ 31;
        }
        
        public boolean equals (Object o) {
            if (o == this) {
                return true;
            }
            if (o instanceof PovRunner) {
                return ((PovRunner) o).sceneFile.equals(sceneFile);
            } else {
                return false;
            }
        }
    }
    
    /**
     * Does platform-specific shell quoting of file names passed on the
     * command line to povray.  Note the cygwin command line povray for
     * windows does not like spaces in path names regardless of quoting
     * (tried it with unix style quoting as well).
     */
    private String quote (String fname) {
        if (Utilities.isWindows()) {
            if (fname.indexOf(' ') != -1) {
                return "\"" + fname + "\"";
            } else {
                return fname;
            }
        } else {
            if (fname.indexOf(' ') != -1) {
                //XXX check this on unix
                StringBuffer sb = new StringBuffer (fname.length() + 5);
                char[] c = fname.toCharArray();
                for (int i=0; i < c.length; i++) {
                    if (Character.isWhitespace(c[i])) {
                        sb.append ('\\');
                        sb.append (c[i]);
                    } else {
                        sb.append (c[i]);
                    }
                }
                return sb.toString();
            } else {
                return fname;
            }
        }
    }
    
    private static final String SETTINGS_DIR = "Povray/RendererSettings";
    
    /**
     * Returns <i>display names</i> of available renderer settings.
     */
    public String[] getAvailableRendererSettings() {
        return new String[] {"placeholder"};
    }
    
    public String getPreferredConfigurationName() {
        return "placeholder";
    }    
    
    /**
     * Get a specific Properties instance that corresponds with a display name.
     * @param name - localized name, as returned by getAvailableRendererSettings().
     *  Implementation detail:  If null, will return the last known preferred
     *  settings, or if no preferred settings known, some set of known settings
     */
    public Properties getRendererSettings (String name) {
        Properties result = new Properties();
        result.setProperty ("W", "640");
        result.setProperty ("H", "480");
        result.setProperty ("Q", "9");
        result.setProperty ("FN", "8");
        result.setProperty ("A", "0.3");
        return result;
    }

    /**
     * Get the location of the povray executable.  This is stored in 
     * Preferences across sessions.  If it is either unknown or the file 
     * no longer exists, the user will be prompted.
     *
     * @return The executable file, or null if the user cancels
     */
    private static File getPovray() {
        if (povray == null || !povray.exists()) {
            Preferences prefs = Preferences.userNodeForPackage(RendererServiceImpl.class);
            String loc = prefs.get(KEY_POVRAY_EXEC, null);

            if (loc != null) {
                povray = new File (loc);
            }
            
            if (povray == null || !povray.exists()) {
                File maybePov = locate("TTL_FindPovray");
                
                if (maybePov.getPath().endsWith("pvengine.exe")) {
                    //Warn the user to get a command line build
                    NotifyDescriptor msg = new NotifyDescriptor.Confirmation (
                        NbBundle.getMessage(RendererServiceImpl.class, 
                        "MSG_WindowsWarning"), 
                        NotifyDescriptor.WARNING_MESSAGE);

                    Object result = DialogDisplayer.getDefault().notify(msg);
                    if (result == NotifyDescriptor.CANCEL_OPTION) {
                        return null;
                    }
                }
                
                povray = maybePov;

                
                if (povray != null) {
                    prefs.put (KEY_POVRAY_EXEC, povray.getPath());
                }
            }
        }
        return povray;
    }
    
    /**
     * Get the standard povray include directory, asking the user where it 
     * is if need be.
     *
     * @return The includes dir, or null if the user cancels.  Usually is
     *  $POVRAY_HOME/include, so we check there first.
     */
    private static File getStandardIncludeDir (File povray) {
        if (include != null) {
            return include;
        }
        Preferences prefs = Preferences.userNodeForPackage(RendererServiceImpl.class);
        String loc = prefs.get(KEY_POVRAY_INCLUDES, null);
        if (loc != null) {
            include = new File (loc);
            if (!include.exists()) {
                include = null;
            }
        }
        if (include == null) {
            include = new File (povray.getParentFile().getParent() + File.separator + "include");
            if (!include.exists()) {
                include = locate ("TTL_FindIncludes");
                if (include != null) {
                    prefs.put(KEY_POVRAY_INCLUDES, include.getPath());
                } else {
                    include = null;
                }
            }
        }
        return include;
    }
    
    /**
     * Displays a JFileChooser with a custom localized string - used to ask
     * the user where is their povray exe and where is the standard include
     * dir (if not found in the povray install).
     */
    private static File locate(String key) {
        JFileChooser jfc = povray != null ? 
            new JFileChooser(povray.getParentFile()) : new JFileChooser();
        
        jfc.setDialogTitle(NbBundle.getMessage(RendererServiceImpl.class, key));
        jfc.setFileSelectionMode (JFileChooser.FILES_ONLY);
        jfc.showOpenDialog(WindowManager.getDefault().getMainWindow());
        File result = jfc.getSelectedFile();
        return result;
    }
}
