/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.povproject;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import org.netbeans.api.povproject.MainFileProvider;
import org.netbeans.api.povproject.RendererService;
import org.netbeans.spi.project.ActionProvider;
import org.netbeans.spi.project.ui.LogicalViewProvider;
import org.netbeans.spi.project.ui.PrivilegedTemplates;
import org.openide.ErrorManager;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.DataObject;
import org.openide.loaders.DataObjectNotFoundException;
import org.openide.nodes.AbstractNode;
import org.openide.nodes.Children;
import org.openide.nodes.FilterNode;
import org.openide.nodes.Node;
import org.openide.util.Lookup;
import org.openide.util.NbBundle;
import org.openide.util.Utilities;
import org.openide.util.actions.Presenter;
import org.openide.util.lookup.Lookups;
import org.openide.util.lookup.ProxyLookup;

/**
 * Logical view of a Povray project for the project tab in Explorer.
 * Provides a FilterNode wraps the default DataNode
 * for the project, replacing the icon.
 *
 * @author Timothy Boudreau
 */
class PovrayLogicalView implements LogicalViewProvider {
    private PovProject project;
    
    /** Creates a new instance of PovrayLogicalView */
    public PovrayLogicalView(PovProject project) {
        this.project = project;
    }

    public org.openide.nodes.Node createLogicalView() {
        try {
            //Get the scenes directory, creating if deleted
            FileObject scenes = project.getScenesFolder(true);
            
            //Get the DataObject that represents it
            DataObject scenesDataObject = 
                    DataObject.find (scenes);
            
            //Get its default node - we'll wrap our node around it to change the
            //display name, icon, etc.
            Node scenesNode = scenesDataObject.getNodeDelegate();
            
            //This FilterNode will be our project node
            return new ScenesNode (scenesNode, project);
        } catch (DataObjectNotFoundException donfe) {
            ErrorManager.getDefault().notify(donfe);
            return new AbstractNode (Children.LEAF);
        }
    }

    public Node findPath(org.openide.nodes.Node root, Object target) {
        //XXX NOT IMPLEMENTED
        return null;
    }

    /** This is the node you actually see in the project tab for the project */
    private static final class ScenesNode extends FilterNode {
        final PovProject project;
        public ScenesNode (Node node, PovProject project) throws DataObjectNotFoundException {
            super (node, new FilterNode.Children (node),
                    //The projects system wants the project in the Node's lookup.
                    //NewAction and friends want the original Node's lookup.
                    //Make a merge of both
                    new ProxyLookup (new Lookup[] { Lookups.singleton(project), 
                    node.getLookup() }));
            this.project = project;
        }
        
        public Image getIcon(int type) {
            return Utilities.loadImage ("org/netbeans/modules/povproject/resources/scenes.gif");
        }
        
        public Image getOpenedIcon(int type) {
            return getIcon(type);
        }      
        
        public String getDisplayName() {
            return project.getProjectDirectory().getName();
        }
        
        public Action[] getActions(boolean context) {
            Action[] orig = super.getActions (context);
            Action[] result = new Action[orig.length+1];
            System.arraycopy(orig, 0, result, 1, orig.length);
            result[0] = new RenderAction(project);
            return result;
        }
    }
    
    private static final class RenderAction extends AbstractAction implements Presenter.Popup {
        private final PovProject project;
        
        public RenderAction (PovProject project) {
            this.project = project;
            putValue (Action.NAME, NbBundle.getMessage(PovrayLogicalView.class,
                    "LBL_RenderProject"));
        }
        

        public JMenuItem getPopupPresenter() {
            JMenu result = new JMenu (this);
            RendererService service = (RendererService) project.getLookup().lookup (RendererService.class);
            String[] settings = service.getAvailableRendererSettings();
            String preferred = service.getPreferredConfigurationName();
            for (int i=0; i < settings.length; i++) {
                //First will be production, add a separator
                if (i == 1) {
                    result.add (new JSeparator());
                }
                JCheckBoxMenuItem item = new JCheckBoxMenuItem (this);
                item.setText (settings[i]);
                if (preferred.equals(settings[i])) {
                    item.setSelected (true);
                }
                result.add (item);
            }
            return result;
        }
        
        public void actionPerformed (ActionEvent ae) {
            JMenuItem item = (JMenuItem) ae.getSource();
            RendererService service = (RendererService) project.getLookup().lookup (RendererService.class);
            MainFileProvider provider = (MainFileProvider) project.getLookup().lookup (MainFileProvider.class);
            
            String target = ae.getSource() == this ? service.getAvailableRendererSettings() [0] : item.getText();
            File scene = FileUtil.toFile (provider.getMainFile());
            service.render(scene, service.getRendererSettings(target));
        }
        
        public boolean isEnabled() {
            //Just lookup whether Build is enabled - if it isn't, we don't have
            //a main file set, so we shouldn't be enabled either
            ActionProvider actions = 
                (ActionProvider) project.getLookup().lookup (ActionProvider.class);
            
            return actions.isActionEnabled(
                    ActionProvider.COMMAND_BUILD,  project.getLookup());
        }
    }   
}
