package newpackage;

public class NewClass {
    
    public NewClass() {
        String s = "OK";
    }
    
}
