package newpackage;

public class Utils {
    
    public static String OK = "OK";
    
}
