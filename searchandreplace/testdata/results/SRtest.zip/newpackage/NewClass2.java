package newpackage;

public class NewClass2 {
    
    public NewClass2() {
        String s2 = Utils.OK;
    }
    
}
